from fastapi import APIRouter

from app.api.routes import calculations, drawio, turbines, valves, utils


api_router = APIRouter()

api_router.include_router(turbines.router, prefix="/turbines", tags=["turbines"])
api_router.include_router(valves.router, prefix="/valves", tags=["valves"])
api_router.include_router(calculations.router, tags=["calculations"])
api_router.include_router(utils.router, prefix="/utils", tags=["utils"])
api_router.include_router(drawio.router, tags=["drawio"])
